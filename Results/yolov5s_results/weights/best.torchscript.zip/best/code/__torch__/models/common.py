class Focus(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.models.common.Conv
  def forward(self: __torch__.models.common.Focus,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_207.SiLU,
    x: Tensor) -> Tensor:
    conv = self.conv
    _0 = torch.slice(x, 2, 0, 9223372036854775807, 2)
    _1 = torch.slice(_0, 3, 0, 9223372036854775807, 2)
    _2 = torch.slice(x, 2, 1, 9223372036854775807, 2)
    _3 = torch.slice(_2, 3, 0, 9223372036854775807, 2)
    _4 = torch.slice(x, 2, 0, 9223372036854775807, 2)
    _5 = torch.slice(_4, 3, 1, 9223372036854775807, 2)
    _6 = torch.slice(x, 2, 1, 9223372036854775807, 2)
    _7 = torch.slice(_6, 3, 1, 9223372036854775807, 2)
    input = torch.cat([_1, _3, _5, _7], 1)
    return (conv).forward(argument_1, input, )
class Conv(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.Conv2d
  act : __torch__.torch.nn.modules.activation.SiLU
  def forward(self: __torch__.models.common.Conv,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_207.SiLU,
    input: Tensor) -> Tensor:
    conv = self.conv
    _8 = (argument_1).forward((conv).forward(input, ), )
    return _8
class BottleneckCSP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.models.common.___torch_mangle_5.Conv
  cv2 : __torch__.torch.nn.modules.conv.___torch_mangle_6.Conv2d
  cv3 : __torch__.torch.nn.modules.conv.___torch_mangle_7.Conv2d
  cv4 : __torch__.models.common.___torch_mangle_10.Conv
  bn : __torch__.torch.nn.modules.batchnorm.BatchNorm2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_11.SiLU
  m : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.models.common.BottleneckCSP,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_207.SiLU,
    argument_2: Tensor) -> Tensor:
    cv4 = self.cv4
    act = self.act
    bn = self.bn
    cv2 = self.cv2
    cv3 = self.cv3
    m = self.m
    cv1 = self.cv1
    _9 = (cv1).forward(argument_1, argument_2, )
    _10 = (cv3).forward((m).forward(argument_1, _9, ), )
    input = torch.cat([_10, (cv2).forward(argument_2, )], 1)
    _11 = (act).forward((bn).forward(input, ), )
    return (cv4).forward(argument_1, _11, )
class Bottleneck(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.models.common.___torch_mangle_14.Conv
  cv2 : __torch__.models.common.___torch_mangle_17.Conv
  def forward(self: __torch__.models.common.Bottleneck,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_207.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    cv1 = self.cv1
    _12 = (cv1).forward(argument_1, argument_2, )
    input = torch.add(argument_2, (cv2).forward(argument_1, _12, ))
    return input
class SPP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.models.common.___torch_mangle_95.Conv
  cv2 : __torch__.models.common.___torch_mangle_98.Conv
  m : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.models.common.SPP,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_207.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    _2 = getattr(m, "2")
    m0 = self.m
    _1 = getattr(m0, "1")
    m1 = self.m
    _0 = getattr(m1, "0")
    cv1 = self.cv1
    _13 = (cv1).forward(argument_1, argument_2, )
    _14 = [_13, (_0).forward(_13, ), (_1).forward(_13, ), (_2).forward(_13, )]
    input = torch.cat(_14, 1)
    return (cv2).forward(argument_1, input, )
class Concat(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.models.common.Concat,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    input = torch.cat([argument_1, argument_2], 1)
    return input
