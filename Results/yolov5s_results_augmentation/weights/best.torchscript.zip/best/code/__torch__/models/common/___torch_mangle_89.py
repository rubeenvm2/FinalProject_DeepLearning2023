class BottleneckCSP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.models.common.___torch_mangle_59.Conv
  cv2 : __torch__.torch.nn.modules.conv.___torch_mangle_60.Conv2d
  cv3 : __torch__.torch.nn.modules.conv.___torch_mangle_61.Conv2d
  cv4 : __torch__.models.common.___torch_mangle_64.Conv
  bn : __torch__.torch.nn.modules.batchnorm.___torch_mangle_65.BatchNorm2d
  act : __torch__.torch.nn.modules.activation.___torch_mangle_66.SiLU
  m : __torch__.torch.nn.modules.container.___torch_mangle_88.Sequential
  def forward(self: __torch__.models.common.___torch_mangle_89.BottleneckCSP,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_207.SiLU,
    argument_2: Tensor) -> Tensor:
    cv4 = self.cv4
    act = self.act
    bn = self.bn
    cv2 = self.cv2
    cv3 = self.cv3
    m = self.m
    cv1 = self.cv1
    _0 = (cv1).forward(argument_1, argument_2, )
    _1 = (cv3).forward((m).forward(argument_1, _0, ), )
    input = torch.cat([_1, (cv2).forward(argument_2, )], 1)
    _2 = (act).forward((bn).forward(input, ), )
    return (cv4).forward(argument_1, _2, )
